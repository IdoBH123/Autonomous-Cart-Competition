// Pin definitions
const int ledPin = 13;

void setup() {
  // Initialize the LED pin as an output
  pinMode(ledPin, OUTPUT);

  // Initialize Serial1 for Bluetooth communication
  Serial1.begin(9600);
  
  // Initialize Serial for debugging
  Serial.begin(9600);
}

void loop() {
  // Check if data is available on Serial1
  if (Serial1.available()) {
    char receivedChar = Serial1.read();

    // Debugging
    Serial.print("Received: ");
    Serial.println(receivedChar);
    
    // Turn LED on or off based on the received character
    if (receivedChar == '1') {
      digitalWrite(ledPin, HIGH);  // Turn LED on
      Serial.println("LED ON");
    } else if (receivedChar == '0') {
      digitalWrite(ledPin, LOW);   // Turn LED off
      Serial.println("LED OFF");
    }
  }
}
