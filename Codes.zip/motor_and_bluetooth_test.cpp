#include <AFMotor.h>
#include <SoftwareSerial.h>


SoftwareSerial BTSerial(18, 19);


// Create motor objects
AF_DCMotor motor1(1); // Motor connected to M1 terminal
AF_DCMotor motor2(2); // Motor connected to M2 terminal
AF_DCMotor motor3(3); // Motor connected to M3 terminal
AF_DCMotor motor4(4); // Motor connected to M4 terminal

const int ledPin = 13;
char command;


void setup() {
  // Set initial speed to 0
  motor1.setSpeed(0);
  motor2.setSpeed(0);
  motor3.setSpeed(0);
  motor4.setSpeed(0);

  // Initialize LED pin
  pinMode(ledPin, OUTPUT);
  //digitalWrite(ledPin, LOW);

  // Initialize serial communication
  Serial1.begin(9600);
  BTSerial.begin(9600);
  
}

void loop() {
  // Check for Bluetooth commands
  if (Serial1.available()) {
   char command = Serial1.read();
    // Debugging
    //Serial.print("Received: ");
    //Serial.println(receivedChar);

    // Control LED based on received command
    if (command == '1') {
      digitalWrite(ledPin, HIGH);  // Turn LED on
      moveForward(255);
      delay(2000);
      // Move backward at half speed
      moveBackward(128);
      delay(2000);
      
      // Turn right at full speed
      turnRight(120);
      delay(2000);
      
      // Turn left at full speed
      turnLeft(120);
      delay(2000);
      
      // Stop for 2 seconds
      stopMotors();
      delay(2000);

    } else if (command == '0') {
      digitalWrite(ledPin, LOW);   // Turn LED off
    }
    // Control motors based on received command (example)
    /*if (command == 'F') {
      moveForward(255);
    } else if (command == 'B') {
      moveBackward(255);
    } else if (command == 'L') {
      turnLeft(255);
    } else if (command == 'R') {
      turnRight(255);
    } else if (command == 'S') {
      stopMotors();
    /*}
  }



  // Additional logic can be added here
  // Example: Move forward at full speed for 2 seconds
  /*
  moveForward(255);
  delay(2000);
  
  // Move backward at half speed
  moveBackward(128);
  delay(2000);
  
  // Turn right at full speed
  turnRight(120);
  delay(2000);
  
  // Turn left at full speed
  turnLeft(120);
  delay(2000);
  
  // Stop for 2 seconds
  stopMotors();
  delay(2000);
  */
}
}


void moveForward(int speed) {
  motor1.setSpeed(speed);
  motor2.setSpeed(speed);
  motor3.setSpeed(speed);
  motor4.setSpeed(speed);
  motor1.run(FORWARD);
  motor2.run(FORWARD);
  motor3.run(FORWARD);
  motor4.run(FORWARD);
}

void moveBackward(int speed) {
  motor1.setSpeed(speed);
  motor2.setSpeed(speed);
  motor3.setSpeed(speed);
  motor4.setSpeed(speed);
  motor1.run(BACKWARD);
  motor2.run(BACKWARD);
  motor3.run(BACKWARD);
  motor4.run(BACKWARD);
}

void turnRight(int speed) {
  motor1.setSpeed(speed);
  motor2.setSpeed(speed);
  motor3.setSpeed(speed);
  motor4.setSpeed(speed);
  motor1.run(FORWARD);
  motor2.run(FORWARD);
  motor3.run(BACKWARD);
  motor4.run(BACKWARD);
}

void turnLeft(int speed) {
  motor1.setSpeed(speed);
  motor2.setSpeed(speed);
  motor3.setSpeed(speed);
  motor4.setSpeed(speed);
  motor1.run(BACKWARD);
  motor2.run(BACKWARD);
  motor3.run(FORWARD);
  motor4.run(FORWARD);
}

void stopMotors() {
  motor1.run(RELEASE);
  motor2.run(RELEASE);
  motor3.run(RELEASE);
  motor4.run(RELEASE);
}
