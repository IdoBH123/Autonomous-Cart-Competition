const int pinnum = 11; // define the pin num as a constant

void setup() {
  pinMode(pinnum, OUTPUT); // configure pin number as an output
}

void loop() {
  for (int i = 0; i < 100; i++) { // 148 is number of cycles for "external high voltage"
    digitalWrite(pinnum, LOW); // set pin num to a low voltage level
    delayMicroseconds(10.5); // Pauses the program for another 13.15 microseconds
    digitalWrite(pinnum, HIGH); // set pin num to a high voltage level
    delayMicroseconds(10.5); // pin num remains in the high state for 13.15 microseconds
  }
  
  // Pause for 3.8924 milliseconds
  digitalWrite(pinnum, LOW);
  delay(3); // Pause for 3.8924 milliseconds, external frequency = 128.455 Hz
}
